<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Lista przyjaciół</title>
    <link rel="stylesheet" href="styl.css">
</head>
<body>
    <div class="baner"><h1>Portal Społecznościowy - moje konto</h1></div>
    <div class="glowny">
        <h2>Moje zainteresowania</h2>
        <ul>
            <li>muzyka</li>
            <li>film</li>
            <li>komputery</li>
        </ul>
        <h2>Moi Znajomi</h2>

            <?php
                $connect =  mysqli_connect("localhost","root","","dane");

                echo "test";
                mysqli_close($connect);
            ?>
        <div class="zdjecie"></div>
        <div class="opis"></div>
        <div class="linia"></div>
    </div>
    <div class="stopka1">Stronę wykonał:00000000</div>
    <div class="stopka2">
        <a href="mailto:ja@portal.pl">napisz do mnie</a>
    </div>
    <div style="clear: both;"></div>

</body>
</html>